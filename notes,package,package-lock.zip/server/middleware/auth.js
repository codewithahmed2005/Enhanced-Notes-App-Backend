const fs = require('fs');
const path = require('path');

// Simple session storage
const sessions = {};

function requireAuth(req, res, next) {
  const sessionId = req.cookies.sessionId;
  
  if (!sessionId || !sessions[sessionId]) {
    return res.status(401).json({ error: 'Please login first' });
  }
  
  req.user = sessions[sessionId];
  next();
}

function createSession(username) {
  const sessionId = Date.now().toString();
  sessions[sessionId] = { username };
  return sessionId;
}

function destroySession(sessionId) {
  delete sessions[sessionId];
}

function getSession(sessionId) {
  return sessions[sessionId];
}

module.exports = {
  requireAuth,
  createSession,
  destroySession,
  getSession
};