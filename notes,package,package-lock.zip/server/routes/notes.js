const express = require('express');
const { requireAuth } = require('../middleware/auth');
const Note = require('../models/Note');

const router = express.Router();

// All routes require authentication
router.use(requireAuth);

// GET /api/notes - Get all notes for user
router.get('/', (req, res) => {
  try {
    const notes = Note.getUserNotes(req.user.username);
    
    // Sort: pinned notes first, then by updated date
    const sortedNotes = notes.sort((a, b) => {
      if (a.pinned && !b.pinned) return -1;
      if (!a.pinned && b.pinned) return 1;
      return new Date(b.updatedAt) - new Date(a.updatedAt);
    });
    
    res.json(sortedNotes);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch notes' });
  }
});

// POST /api/notes - Create new note
router.post('/', (req, res) => {
  const { title, content, tags } = req.body;
  
  if (!title || !content) {
    return res.status(400).json({ error: 'Title and content are required' });
  }
  
  const noteData = {
    title,
    content,
    tags: tags || [],
    username: req.user.username
  };
  
  const newNote = Note.createNote(noteData);
  
  if (newNote) {
    res.status(201).json(newNote);
  } else {
    res.status(500).json({ error: 'Failed to create note' });
  }
});

// PUT /api/notes/:id - Update note
router.put('/:id', (req, res) => {
  const { id } = req.params;
  const { title, content, tags } = req.body;
  
  if (!title || !content) {
    return res.status(400).json({ error: 'Title and content are required' });
  }
  
  const updates = { title, content, tags: tags || [] };
  const updatedNote = Note.updateNote(id, req.user.username, updates);
  
  if (updatedNote) {
    res.json(updatedNote);
  } else {
    res.status(404).json({ error: 'Note not found' });
  }
});

// DELETE /api/notes/:id - Delete note
router.delete('/:id', (req, res) => {
  const { id } = req.params;
  
  if (Note.deleteNote(id, req.user.username)) {
    res.json({ message: 'Note deleted successfully' });
  } else {
    res.status(404).json({ error: 'Note not found' });
  }
});

// GET /api/notes/search?q=query - Search notes
router.get('/search', (req, res) => {
  const { q } = req.query;
  
  if (!q) {
    return res.status(400).json({ error: 'Search query is required' });
  }
  
  try {
    const results = Note.searchNotes(req.user.username, q);
    res.json(results);
  } catch (error) {
    res.status(500).json({ error: 'Search failed' });
  }
});

// POST /api/notes/:id/pin - Toggle pin status
router.post('/:id/pin', (req, res) => {
  const { id } = req.params;
  
  const updatedNote = Note.togglePin(id, req.user.username);
  
  if (updatedNote) {
    res.json(updatedNote);
  } else {
    res.status(404).json({ error: 'Note not found' });
  }
});

// GET /api/notes/tags - Get all tags for user
router.get('/tags/all', (req, res) => {
  try {
    const tags = Note.getUserTags(req.user.username);
    res.json(tags);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch tags' });
  }
});

module.exports = router;