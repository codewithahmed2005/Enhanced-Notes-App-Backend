const express = require('express');
const fs = require('fs');
const path = require('path');
const { createSession, destroySession, getSession } = require('../middleware/auth');

const router = express.Router();

// Helper functions
function readUsers() {
  try {
    const data = fs.readFileSync(path.join(__dirname, '../..', 'users.json'), 'utf8');
    return JSON.parse(data);
  } catch (error) {
    return [];
  }
}

function writeUsers(users) {
  try {
    fs.writeFileSync(path.join(__dirname, '../..', 'users.json'), JSON.stringify(users, null, 2));
    return true;
  } catch (error) {
    return false;
  }
}

// POST /api/signup
router.post('/signup', (req, res) => {
  const { username, password } = req.body;
  
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required' });
  }
  
  if (username.length < 3) {
    return res.status(400).json({ error: 'Username must be at least 3 characters' });
  }
  
  const users = readUsers();
  
  if (users.find(user => user.username === username)) {
    return res.status(400).json({ error: 'Username already exists' });
  }
  
  const newUser = { username, password };
  users.push(newUser);
  
  if (writeUsers(users)) {
    res.json({ message: 'User created successfully! Please login.' });
  } else {
    res.status(500).json({ error: 'Failed to create user' });
  }
});

// POST /api/login
router.post('/login', (req, res) => {
  const { username, password } = req.body;
  
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required' });
  }
  
  const users = readUsers();
  const user = users.find(u => u.username === username && u.password === password);
  
  if (!user) {
    return res.status(401).json({ error: 'Invalid username or password' });
  }
  
  const sessionId = createSession(username);
  res.cookie('sessionId', sessionId, { httpOnly: true });
  res.json({ message: 'Login successful!', username });
});

// GET /api/logout
router.get('/logout', (req, res) => {
  const sessionId = req.cookies.sessionId;
  
  if (sessionId) {
    destroySession(sessionId);
  }
  
  res.clearCookie('sessionId');
  res.json({ message: 'Logout successful!' });
});

// GET /api/check-auth
router.get('/check-auth', (req, res) => {
  const sessionId = req.cookies.sessionId;
  const session = getSession(sessionId);
  
  if (session) {
    res.json({ authenticated: true, username: session.username });
  } else {
    res.json({ authenticated: false });
  }
});

module.exports = router;