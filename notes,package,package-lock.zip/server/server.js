const express = require('express');
const cookieParser = require('cookie-parser');
const path = require('path');

const app = express();
const PORT = 3000;

// Import routes
const authRoutes = require('./routes/auth');
const notesRoutes = require('./routes/notes');

// Middleware
app.use(express.json({ limit: '10mb' }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, '../public')));

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/notes', notesRoutes);

// Serve auth pages
app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/login.html'));
});

app.get('/signup', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/signup.html'));
});

// Serve main app
app.get('/app', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

// Redirect root to login
app.get('/', (req, res) => {
  res.redirect('/login');
});

// Start server
app.listen(PORT, () => {
  console.log(`Enhanced Notes App running at http://localhost:${PORT}`);
  console.log('Available routes:');
  console.log('  GET  /login  - Login page');
  console.log('  GET  /signup - Signup page');
  console.log('  GET  /app    - Main notes app');
  console.log('Features: Search, Tags, Pinning, Rich Text Editor, Dark Mode');
});