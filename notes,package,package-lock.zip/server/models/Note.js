const fs = require('fs');
const path = require('path');

class Note {
  constructor() {
    this.notesFile = path.join(__dirname, '../..', 'notes.json');
  }

  readNotes() {
    try {
      const data = fs.readFileSync(this.notesFile, 'utf8');
      return JSON.parse(data);
    } catch (error) {
      return [];
    }
  }

  writeNotes(notes) {
    try {
      fs.writeFileSync(this.notesFile, JSON.stringify(notes, null, 2));
      return true;
    } catch (error) {
      console.error('Error writing notes:', error);
      return false;
    }
  }

  // Get all notes for a user
  getUserNotes(username) {
    const notes = this.readNotes();
    return notes.filter(note => note.username === username);
  }

  // Create new note
  createNote(noteData) {
    const notes = this.readNotes();
    const newNote = {
      id: Date.now().toString(),
      title: noteData.title,
      content: noteData.content,
      tags: noteData.tags || [],
      pinned: false,
      username: noteData.username,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    notes.push(newNote);
    return this.writeNotes(notes) ? newNote : null;
  }

  // Update note
  updateNote(id, username, updates) {
    const notes = this.readNotes();
    const noteIndex = notes.findIndex(note => note.id === id && note.username === username);
    
    if (noteIndex === -1) return null;
    
    notes[noteIndex] = {
      ...notes[noteIndex],
      ...updates,
      updatedAt: new Date().toISOString()
    };
    
    return this.writeNotes(notes) ? notes[noteIndex] : null;
  }

  // Delete note
  deleteNote(id, username) {
    const notes = this.readNotes();
    const filteredNotes = notes.filter(note => !(note.id === id && note.username === username));
    
    if (notes.length === filteredNotes.length) return false;
    
    return this.writeNotes(filteredNotes);
  }

  // Search notes
  searchNotes(username, query) {
    const notes = this.getUserNotes(username);
    const searchTerm = query.toLowerCase();
    
    return notes.filter(note => 
      note.title.toLowerCase().includes(searchTerm) ||
      note.content.toLowerCase().includes(searchTerm) ||
      note.tags.some(tag => tag.toLowerCase().includes(searchTerm))
    );
  }

  // Toggle pin status
  togglePin(id, username) {
    const notes = this.readNotes();
    const noteIndex = notes.findIndex(note => note.id === id && note.username === username);
    
    if (noteIndex === -1) return null;
    
    notes[noteIndex].pinned = !notes[noteIndex].pinned;
    notes[noteIndex].updatedAt = new Date().toISOString();
    
    return this.writeNotes(notes) ? notes[noteIndex] : null;
  }

  // Get all tags for a user
  getUserTags(username) {
    const notes = this.getUserNotes(username);
    const allTags = notes.flatMap(note => note.tags);
    return [...new Set(allTags)]; // Remove duplicates
  }
}

module.exports = new Note();